import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os
import numpy as np
import matplotlib.pyplot as plt

# This file contains the code to train a CNN model for pneumonia detection
# In a real implementation, you would train this model with a dataset of X-ray images

def build_model(input_shape=(224, 224, 3)):
    """
    Build a CNN model for pneumonia detection
    
    Args:
        input_shape: Shape of input images (height, width, channels)
        
    Returns:
        A compiled Keras model
    """
    model = Sequential([
        # First convolutional layer
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        MaxPooling2D(2, 2),
        
        # Second convolutional layer
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D(2, 2),
        
        # Third convolutional layer
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D(2, 2),
        
        # Fourth convolutional layer
        Conv2D(128, (3, 3), activation='relu'),
        MaxPooling2D(2, 2),
        
        # Flatten the output and connect to dense layers
        Flatten(),
        Dropout(0.5),  # Add dropout to prevent overfitting
        Dense(512, activation='relu'),
        Dense(1, activation='sigmoid')  # Binary classification: normal vs pneumonia
    ])
    
    # Compile the model
    model.compile(
        optimizer=Adam(learning_rate=0.0001),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def train_model(model, train_dir, validation_dir, epochs=20, batch_size=32):
    """
    Train the model using data augmentation
    
    Args:
        model: The compiled Keras model
        train_dir: Directory containing training data
        validation_dir: Directory containing validation data
        epochs: Number of epochs to train
        batch_size: Batch size for training
        
    Returns:
        Training history
    """
    # Data augmentation for training
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=40,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    
    # Only rescaling for validation
    validation_datagen = ImageDataGenerator(rescale=1./255)
    
    # Flow training images in batches
    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='binary'
    )
    
    # Flow validation images in batches
    validation_generator = validation_datagen.flow_from_directory(
        validation_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='binary'
    )
    
    # Train the model
    history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=epochs,
        validation_data=validation_generator,
        validation_steps=validation_generator.samples // batch_size
    )
    
    return history

def evaluate_model(model, test_dir, batch_size=32):
    """
    Evaluate the model on test data
    
    Args:
        model: The trained Keras model
        test_dir: Directory containing test data
        batch_size: Batch size for evaluation
    
    Returns:
        Test accuracy and loss
    """
    test_datagen = ImageDataGenerator(rescale=1./255)
    
    test_generator = test_datagen.flow_from_directory(
        test_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode='binary'
    )
    
    test_loss, test_acc = model.evaluate(test_generator)
    print(f'Test accuracy: {test_acc:.4f}')
    print(f'Test loss: {test_loss:.4f}')
    
    return test_acc, test_loss

def plot_training_history(history):
    """
    Plot the training and validation accuracy/loss
    
    Args:
        history: Training history from model.fit
    """
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    
    epochs_range = range(len(acc))
    
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(epochs_range, acc, label='Training Accuracy')
    plt.plot(epochs_range, val_acc, label='Validation Accuracy')
    plt.legend(loc='lower right')
    plt.title('Training and Validation Accuracy')
    
    plt.subplot(1, 2, 2)
    plt.plot(epochs_range, loss, label='Training Loss')
    plt.plot(epochs_range, val_loss, label='Validation Loss')
    plt.legend(loc='upper right')
    plt.title('Training and Validation Loss')
    
    plt.savefig('training_history.png')
    plt.show()

def save_model(model, model_path='pneumonia_model'):
    """
    Save the trained model
    
    Args:
        model: The trained Keras model
        model_path: Path to save the model
    """
    model.save(model_path)
    print(f"Model saved to {model_path}")

# Example usage (commented out since we don't have the dataset in this environment)
"""
if __name__ == "__main__":
    # Define paths to your dataset directories
    base_dir = 'chest_xray'
    train_dir = os.path.join(base_dir, 'train')
    validation_dir = os.path.join(base_dir, 'val')
    test_dir = os.path.join(base_dir, 'test')
    
    # Build and train the model
    model = build_model()
    history = train_model(model, train_dir, validation_dir, epochs=20)
    
    # Evaluate the model
    evaluate_model(model, test_dir)
    
    # Plot training history
    plot_training_history(history)
    
    # Save the model
    save_model(model, 'pneumonia_detection_model')
"""