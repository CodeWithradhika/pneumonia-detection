from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import numpy as np
import uuid
import time
from werkzeug.utils import secure_filename
from datetime import datetime
import tensorflow as tf
from PIL import Image
import io
import json

app = Flask(__name__)
CORS(app)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configure storage for results
RESULTS_FILE = 'results.json'

# Load model
def load_model():
    try:
        # In a real application, you would load a pre-trained model
        # For demonstration, we'll create a dummy model that returns random predictions
        print("Loading pneumonia detection model...")
        # Simulating model load time
        time.sleep(2)
        print("Model loaded successfully!")
        return "dummy_model"
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

# Preprocess image
def preprocess_image(img_path):
    try:
        # Open the image
        img = Image.open(img_path)
        
        # Convert to RGB if it's not
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Resize to the size expected by the model
        img = img.resize((224, 224))
        
        # Convert to numpy array and normalize
        img_array = np.array(img) / 255.0
        
        # Expand dimensions to match model input shape [batch_size, height, width, channels]
        img_array = np.expand_dims(img_array, axis=0)
        
        return img_array
    except Exception as e:
        print(f"Error preprocessing image: {e}")
        return None

# Make prediction
def predict(model, img_array):
    try:
        # In a real application, you would use the model to make predictions
        # For demonstration, we'll return random predictions
        
        # Simulate processing time
        time.sleep(1)
        
        # Generate a random prediction (0 for NORMAL, 1 for PNEUMONIA)
        # For demo purposes, let's make it slightly biased towards pneumonia
        if np.random.random() > 0.4:
            prediction = "PNEUMONIA"
            confidence = np.random.uniform(0.7, 0.98)  # Higher confidence for pneumonia
        else:
            prediction = "NORMAL"
            confidence = np.random.uniform(0.65, 0.95)  # Slightly lower confidence for normal
            
        return {
            "prediction": prediction,
            "confidence": float(confidence)
        }
    except Exception as e:
        print(f"Error making prediction: {e}")
        return None

# Initialize model
model = load_model()

# Load existing results or create empty list
def load_results():
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, 'r') as f:
            return json.load(f)
    return []

# Save results
def save_results(results):
    with open(RESULTS_FILE, 'w') as f:
        json.dump(results, f)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if file:
        # Generate a unique ID for this prediction
        result_id = str(uuid.uuid4())
        
        # Save the uploaded file
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{result_id}_{filename}")
        file.save(file_path)
        
        # Preprocess the image
        img_array = preprocess_image(file_path)
        if img_array is None:
            return jsonify({"error": "Error preprocessing image"}), 500
        
        # Make prediction
        prediction_result = predict(model, img_array)
        if prediction_result is None:
            return jsonify({"error": "Error making prediction"}), 500
        
        # Save the result
        results = load_results()
        result = {
            "id": result_id,
            "filename": filename,
            "date": datetime.now().isoformat(),
            "prediction": prediction_result["prediction"],
            "confidence": prediction_result["confidence"],
            "file_path": file_path
        }
        results.append(result)
        save_results(results)
        
        # Return the prediction
        return jsonify({
            "id": result_id,
            "prediction": prediction_result["prediction"],
            "confidence": prediction_result["confidence"]
        })

@app.route('/api/results/<result_id>', methods=['GET'])
def get_result(result_id):
    results = load_results()
    
    for result in results:
        if result["id"] == result_id:
            return jsonify(result)
    
    return jsonify({"error": "Result not found"}), 404

@app.route('/api/history', methods=['GET'])
def get_history():
    results = load_results()
    
    # Sort by date (newest first)
    results.sort(key=lambda x: x["date"], reverse=True)
    
    # Remove file_path from the response for security
    clean_results = []
    for result in results:
        clean_result = result.copy()
        if "file_path" in clean_result:
            del clean_result["file_path"]
        clean_results.append(clean_result)
    
    return jsonify(clean_results)

if __name__ == '__main__':
    app.run(debug=True, port=5000)