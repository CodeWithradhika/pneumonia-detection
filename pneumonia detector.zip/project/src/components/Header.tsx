import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Settings as Lungs, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-gradient-to-r from-blue-900 to-blue-700 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <NavLink to="/" className="flex items-center space-x-2">
            <Lungs className="h-8 w-8" />
            <span className="font-bold text-xl">PneumoScan</span>
          </NavLink>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            <NavLink 
              to="/"
              className={({ isActive }) => 
                `py-2 hover:text-blue-200 transition-colors ${isActive ? 'font-semibold border-b-2 border-white' : ''}`
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/upload"
              className={({ isActive }) => 
                `py-2 hover:text-blue-200 transition-colors ${isActive ? 'font-semibold border-b-2 border-white' : ''}`
              }
            >
              Detect
            </NavLink>
            <NavLink 
              to="/history"
              className={({ isActive }) => 
                `py-2 hover:text-blue-200 transition-colors ${isActive ? 'font-semibold border-b-2 border-white' : ''}`
              }
            >
              History
            </NavLink>
            <NavLink 
              to="/about"
              className={({ isActive }) => 
                `py-2 hover:text-blue-200 transition-colors ${isActive ? 'font-semibold border-b-2 border-white' : ''}`
              }
            >
              About
            </NavLink>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white focus:outline-none"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-3 space-y-3 pb-4">
            <NavLink 
              to="/"
              className={({ isActive }) => 
                `block py-2 px-3 rounded ${isActive ? 'bg-blue-800' : 'hover:bg-blue-800'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </NavLink>
            <NavLink 
              to="/upload"
              className={({ isActive }) => 
                `block py-2 px-3 rounded ${isActive ? 'bg-blue-800' : 'hover:bg-blue-800'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              Detect
            </NavLink>
            <NavLink 
              to="/history"
              className={({ isActive }) => 
                `block py-2 px-3 rounded ${isActive ? 'bg-blue-800' : 'hover:bg-blue-800'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              History
            </NavLink>
            <NavLink 
              to="/about"
              className={({ isActive }) => 
                `block py-2 px-3 rounded ${isActive ? 'bg-blue-800' : 'hover:bg-blue-800'}`
              }
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </NavLink>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;