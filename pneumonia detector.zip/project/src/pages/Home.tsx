import React from 'react';
import { NavLink } from 'react-router-dom';
import { Upload, History, Info, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto">
      <section className="py-10 mb-10 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
          Pneumonia Detection <span className="text-blue-600">Through AI</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Upload chest X-ray images and get instant AI-powered pneumonia detection
          with clinical-grade accuracy.
        </p>
        <div className="mt-8">
          <NavLink 
            to="/upload" 
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg shadow-md inline-flex items-center transition-all duration-300 transform hover:scale-105"
          >
            Start Detection
            <ArrowRight className="ml-2 h-5 w-5" />
          </NavLink>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white rounded-xl shadow-md p-6 transition-all duration-300 hover:shadow-lg">
          <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
            <Upload className="h-7 w-7 text-blue-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Upload X-Ray</h2>
          <p className="text-gray-600">
            Upload a chest X-ray image in common formats like JPEG, PNG, or DICOM. Our system supports high-resolution medical imagery.
          </p>
          <NavLink 
            to="/upload" 
            className="inline-flex items-center mt-4 text-blue-600 font-medium hover:text-blue-800"
          >
            Go to Upload
            <ArrowRight className="ml-1 h-4 w-4" />
          </NavLink>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 transition-all duration-300 hover:shadow-lg">
          <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
            <Info className="h-7 w-7 text-blue-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Get Results</h2>
          <p className="text-gray-600">
            Receive instant analysis with probability scores, detection regions, and expert-level insights on pneumonia presence.
          </p>
          <NavLink 
            to="/about" 
            className="inline-flex items-center mt-4 text-blue-600 font-medium hover:text-blue-800"
          >
            Learn More
            <ArrowRight className="ml-1 h-4 w-4" />
          </NavLink>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 transition-all duration-300 hover:shadow-lg">
          <div className="bg-blue-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
            <History className="h-7 w-7 text-blue-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Track History</h2>
          <p className="text-gray-600">
            Access your previous scan results, compare analyses over time, and export your scan history for professional use.
          </p>
          <NavLink 
            to="/history" 
            className="inline-flex items-center mt-4 text-blue-600 font-medium hover:text-blue-800"
          >
            View History
            <ArrowRight className="ml-1 h-4 w-4" />
          </NavLink>
        </div>
      </section>

      <section className="bg-blue-50 rounded-2xl p-8 mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-blue-900 mb-3">How It Works</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Our deep learning model has been trained on thousands of X-ray images to accurately detect pneumonia.
          </p>
        </div>
        
        <div className="grid md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <span className="text-blue-700 font-bold text-xl">1</span>
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Upload</h3>
            <p className="text-sm text-gray-600">Upload your chest X-ray image</p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <span className="text-blue-700 font-bold text-xl">2</span>
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Process</h3>
            <p className="text-sm text-gray-600">AI model analyzes the image</p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <span className="text-blue-700 font-bold text-xl">3</span>
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Detect</h3>
            <p className="text-sm text-gray-600">Get detection results with confidence</p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
              <span className="text-blue-700 font-bold text-xl">4</span>
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Track</h3>
            <p className="text-sm text-gray-600">Save results for future reference</p>
          </div>
        </div>
      </section>

      <section className="text-center mb-16">
        <h2 className="text-3xl font-bold text-blue-900 mb-4">Ready to get started?</h2>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Upload your X-ray image now and get instant pneumonia detection results.
        </p>
        <NavLink 
          to="/upload" 
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-lg shadow-md inline-flex items-center transition-all duration-300"
        >
          Start Detection
          <ArrowRight className="ml-2 h-5 w-5" />
        </NavLink>
      </section>
    </div>
  );
};

export default Home;