import React, { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { Upload as UploadIcon, AlertCircle, Loader } from 'lucide-react';
import { toast } from 'react-toastify';
import axios from 'axios';

const Upload: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const selectedFile = acceptedFiles[0];
    
    // Check if file is an image
    if (!selectedFile.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }
    
    setFile(selectedFile);
    setError(null);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.dcm']
    },
    maxFiles: 1
  });

  const handleSubmit = async () => {
    if (!file) {
      setError('Please select an image to upload');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    // Create form data
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      // In a real implementation, this would call your Python backend
      // For demo purposes, we'll use a timeout and simulate a response
      // const response = await axios.post('http://localhost:5000/api/predict', formData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate successful response
      const resultsId = Date.now().toString();
      
      // Add to history (in a real app, this would be handled by the backend)
      const historyItem = {
        id: resultsId,
        filename: file.name,
        date: new Date().toISOString(),
        prediction: Math.random() > 0.5 ? 'PNEUMONIA' : 'NORMAL',
        confidence: Math.random() * 0.3 + 0.7,
        imageUrl: preview
      };
      
      // Save to localStorage (this simulates a database)
      const history = JSON.parse(localStorage.getItem('pneumonia_history') || '[]');
      history.push(historyItem);
      localStorage.setItem('pneumonia_history', JSON.stringify(history));
      
      // Navigate to results page
      navigate(`/results/${resultsId}`);
    } catch (err) {
      console.error(err);
      toast.error('Error processing the image. Please try again.');
      setError('Failed to process the image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-blue-900 mb-2">Upload X-Ray Image</h1>
        <p className="text-gray-600">
          Upload a chest X-ray image for pneumonia detection
        </p>
      </div>
      
      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
            isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
          }`}
        >
          <input {...getInputProps()} />
          
          {preview ? (
            <div className="flex flex-col items-center">
              <img 
                src={preview} 
                alt="X-ray preview" 
                className="max-h-72 mb-4 rounded"
              />
              <p className="text-sm text-gray-500">
                {file?.name} ({(file?.size / 1024 / 1024).toFixed(2)} MB)
              </p>
              <p className="text-blue-600 mt-2">
                Click or drag to replace this image
              </p>
            </div>
          ) : (
            <div className="py-8">
              <UploadIcon className="h-16 w-16 text-blue-400 mx-auto mb-4" />
              <p className="text-lg text-gray-700 mb-2">
                {isDragActive ? 'Drop the file here' : 'Drag & drop an X-ray image here'}
              </p>
              <p className="text-sm text-gray-500 mb-3">
                or click to select a file
              </p>
              <p className="text-xs text-gray-400">
                Supported formats: JPEG, PNG, DICOM
              </p>
            </div>
          )}
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-start">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
        
        <div className="mt-6">
          <button
            onClick={handleSubmit}
            disabled={!file || isLoading}
            className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center transition-colors ${
              !file || isLoading 
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isLoading ? (
              <>
                <Loader className="h-5 w-5 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              'Detect Pneumonia'
            )}
          </button>
        </div>
      </div>
      
      <div className="bg-blue-50 rounded-lg p-6 mb-8">
        <h2 className="text-xl font-semibold text-blue-900 mb-3">Tips for Better Results</h2>
        <ul className="text-gray-700 space-y-2">
          <li className="flex items-start">
            <span className="bg-blue-200 rounded-full w-5 h-5 flex items-center justify-center text-blue-700 font-bold text-xs mr-2 mt-0.5">1</span>
            Upload clear, high-resolution X-ray images
          </li>
          <li className="flex items-start">
            <span className="bg-blue-200 rounded-full w-5 h-5 flex items-center justify-center text-blue-700 font-bold text-xs mr-2 mt-0.5">2</span>
            Ensure the entire chest area is visible in the image
          </li>
          <li className="flex items-start">
            <span className="bg-blue-200 rounded-full w-5 h-5 flex items-center justify-center text-blue-700 font-bold text-xs mr-2 mt-0.5">3</span>
            For best results, use frontal (PA/AP) chest X-rays
          </li>
          <li className="flex items-start">
            <span className="bg-blue-200 rounded-full w-5 h-5 flex items-center justify-center text-blue-700 font-bold text-xs mr-2 mt-0.5">4</span>
            Remove any personal information from the images before uploading
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Upload;