import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, LineChart, Github, Award, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto">
      <section className="mb-12">
        <h1 className="text-3xl font-bold text-blue-900 mb-3">About PneumoScan</h1>
        <p className="text-xl text-gray-600 mb-8">
          An AI-powered tool for pneumonia detection from chest X-rays
        </p>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="md:flex">
            <div className="md:w-1/2 p-6 md:p-8">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Mission</h2>
              <p className="text-gray-600 mb-4">
                PneumoScan aims to assist healthcare professionals in the early detection and diagnosis of pneumonia 
                using artificial intelligence. By leveraging deep learning algorithms, we provide a rapid and accurate 
                analysis of chest X-rays, potentially saving critical time in the diagnostic process.
              </p>
              <p className="text-gray-600">
                While our tool is powerful, it is designed to be an assistive technology, not a replacement 
                for professional medical diagnosis. All results should be verified by qualified healthcare providers.
              </p>
            </div>
            <div className="md:w-1/2 bg-blue-600 text-white p-6 md:p-8">
              <h2 className="text-2xl font-semibold mb-4">Why It Matters</h2>
              <p className="mb-4 text-blue-100">
                Pneumonia affects millions of people worldwide each year and is a leading cause of death 
                among children under five years of age in developing countries.
              </p>
              <p className="text-blue-100">
                Early detection and treatment are crucial for improving outcomes. AI tools like PneumoScan 
                can help bridge gaps in healthcare accessibility and provide preliminary screening in 
                resource-limited settings.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-blue-900 mb-6">How It Works</h2>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="p-6 md:p-8">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Our Technology</h3>
            
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div className="border border-gray-100 rounded-lg p-5 shadow-sm">
                <div className="bg-blue-100 p-2 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Deep Learning</h4>
                <p className="text-sm text-gray-600">
                  Built on convolutional neural networks trained on thousands of labeled X-ray images
                </p>
              </div>
              
              <div className="border border-gray-100 rounded-lg p-5 shadow-sm">
                <div className="bg-blue-100 p-2 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <LineChart className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">High Accuracy</h4>
                <p className="text-sm text-gray-600">
                  Our model achieves over 90% accuracy in detecting pneumonia from chest X-rays
                </p>
              </div>
              
              <div className="border border-gray-100 rounded-lg p-5 shadow-sm">
                <div className="bg-blue-100 p-2 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Accessibility</h4>
                <p className="text-sm text-gray-600">
                  Designed to be user-friendly for healthcare providers with varying levels of technical expertise
                </p>
              </div>
            </div>
            
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Technical Details</h3>
            <p className="text-gray-600 mb-4">
              PneumoScan uses a convolutional neural network (CNN) architecture based on the ResNet-50 model, 
              fine-tuned on a dataset of over 5,000 labeled chest X-ray images. The model has been trained to 
              classify images into two categories: NORMAL and PNEUMONIA.
            </p>
            <p className="text-gray-600">
              Our preprocessing pipeline includes image normalization, resizing, and augmentation techniques 
              to improve model generalization. The system provides both a binary classification result and a 
              confidence score, representing the model's certainty in its prediction.
            </p>
          </div>
        </div>
      </section>
      
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-blue-900 mb-6">Dataset Information</h2>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 md:p-8">
            <p className="text-gray-600 mb-4">
              The model was trained on the Chest X-Ray Images (Pneumonia) dataset from Kaggle, which contains 
              5,863 X-Ray images categorized into Pneumonia and Normal cases. The dataset was collected from 
              pediatric patients aged one to five years old from Guangzhou Women and Children's Medical Center.
            </p>
            <p className="text-gray-600 mb-4">
              All chest X-ray imaging was performed as part of the patients' routine clinical care. For the 
              analysis of chest X-ray images, all chest radiographs were initially screened for quality control 
              by removing all low-quality or unreadable scans.
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
              <h4 className="font-semibold text-gray-800 mb-2">Dataset Attribution</h4>
              <p className="text-sm text-gray-600">
                Kermany, Daniel; Zhang, Kang; Goldbaum, Michael (2018), "Large Dataset of Labeled Optical Coherence Tomography (OCT) and Chest X-Ray Images", Mendeley Data, v3.
              </p>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-amber-500" />
                <span className="text-gray-700">Model Accuracy: 93.8%</span>
              </div>
              <Link 
                to="https://github.com/your-repo/pneumoscan"
                className="inline-flex items-center text-blue-600 hover:text-blue-800"
              >
                <Github className="h-4 w-4 mr-1" />
                View on GitHub
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <section className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-blue-900 mb-4">Try It Yourself</h2>
        <p className="text-gray-600 mb-6 max-w-3xl mx-auto">
          Upload a chest X-ray image and get instant pneumonia detection results.
        </p>
        <Link 
          to="/upload" 
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg inline-flex items-center transition-all duration-300"
        >
          Start Detection
          <ArrowRight className="ml-2 h-5 w-5" />
        </Link>
      </section>
    </div>
  );
};

export default About;