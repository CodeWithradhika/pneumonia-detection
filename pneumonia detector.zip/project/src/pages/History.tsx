import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { FileCog, ExternalLink, Search, AlertCircle } from 'lucide-react';

interface HistoryItem {
  id: string;
  filename: string;
  date: string;
  prediction: 'PNEUMONIA' | 'NORMAL';
  confidence: number;
  imageUrl: string | null;
}

const History: React.FC = () => {
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // In a real app, this would be an API call
    const fetchHistory = () => {
      try {
        setLoading(true);
        
        // Simulate API call delay
        setTimeout(() => {
          const storedHistory = JSON.parse(localStorage.getItem('pneumonia_history') || '[]');
          // Sort by date (newest first)
          const sortedHistory = [...storedHistory].sort((a, b) => 
            new Date(b.date).getTime() - new Date(a.date).getTime()
          );
          
          setHistoryItems(sortedHistory);
          setLoading(false);
        }, 500);
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    };
    
    fetchHistory();
  }, []);

  const filteredHistory = historyItems.filter(item => 
    item.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.prediction.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600 mb-4"></div>
        <p className="text-gray-600">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-blue-900 mb-2">Analysis History</h1>
          <p className="text-gray-600">
            View and manage your past X-ray analyses
          </p>
        </div>
        
        <div className="w-full md:w-auto">
          <div className="relative">
            <input 
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search history..."
              className="pl-10 pr-4 py-2 rounded-lg border border-gray-300 w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <Search className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          </div>
        </div>
      </div>

      {historyItems.length === 0 ? (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <FileCog className="h-16 w-16 text-blue-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">No History Found</h2>
          <p className="text-gray-600 mb-6">
            You haven't analyzed any X-rays yet. Upload an X-ray to get started.
          </p>
          <Link 
            to="/upload" 
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg inline-block"
          >
            Upload X-Ray
          </Link>
        </div>
      ) : filteredHistory.length === 0 ? (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <AlertCircle className="h-16 w-16 text-amber-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">No Results Found</h2>
          <p className="text-gray-600 mb-4">
            No items match your search term: "{searchTerm}"
          </p>
          <button 
            onClick={() => setSearchTerm('')}
            className="text-blue-600 hover:text-blue-800 font-medium"
          >
            Clear Search
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHistory.map(item => (
            <div 
              key={item.id} 
              className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:transform hover:scale-102"
            >
              <div className={`p-3 text-white ${
                item.prediction === 'PNEUMONIA' ? 'bg-red-600' : 'bg-green-600'
              }`}>
                <div className="flex justify-between items-center">
                  <span className="font-medium">{item.prediction}</span>
                  <span className="text-sm">{(item.confidence * 100).toFixed(1)}% confidence</span>
                </div>
              </div>
              
              <div className="p-4">
                <div className="flex justify-center mb-4">
                  {item.imageUrl ? (
                    <img 
                      src={item.imageUrl} 
                      alt="X-ray thumbnail" 
                      className="h-48 rounded object-cover"
                    />
                  ) : (
                    <div className="h-48 w-full bg-gray-100 flex items-center justify-center rounded">
                      <p className="text-gray-400">No image</p>
                    </div>
                  )}
                </div>
                
                <h3 className="font-medium text-gray-800 mb-1 truncate" title={item.filename}>
                  {item.filename}
                </h3>
                <p className="text-sm text-gray-500 mb-3">
                  {formatDistanceToNow(new Date(item.date), { addSuffix: true })}
                </p>
                
                <Link 
                  to={`/results/${item.id}`} 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 rounded flex items-center justify-center"
                >
                  View Details
                  <ExternalLink className="h-3.5 w-3.5 ml-1" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {filteredHistory.length > 0 && (
        <div className="mt-6 text-center text-gray-500 text-sm">
          Showing {filteredHistory.length} of {historyItems.length} results
        </div>
      )}
    </div>
  );
};

export default History;