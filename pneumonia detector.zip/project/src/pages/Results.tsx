import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Download, AlertTriangle, Info, Check, AlertCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions
} from 'chart.js';

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

interface ResultData {
  id: string;
  filename: string;
  date: string;
  prediction: 'PNEUMONIA' | 'NORMAL';
  confidence: number;
  imageUrl: string | null;
}

const Results: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [result, setResult] = useState<ResultData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // In a real app, this would be an API call
    const fetchResult = () => {
      try {
        setLoading(true);
        
        // Simulate API call delay
        setTimeout(() => {
          const history = JSON.parse(localStorage.getItem('pneumonia_history') || '[]');
          const foundResult = history.find((item: ResultData) => item.id === id);
          
          if (foundResult) {
            setResult(foundResult);
          } else {
            setError('Result not found');
          }
          
          setLoading(false);
        }, 500);
      } catch (err) {
        console.error(err);
        setError('Failed to load result data');
        setLoading(false);
      }
    };
    
    fetchResult();
  }, [id]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600 mb-4"></div>
        <p className="text-gray-600">Loading results...</p>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12">
        <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Result Not Found</h2>
        <p className="text-gray-600 mb-6">{error || 'The requested result could not be found'}</p>
        <Link 
          to="/upload" 
          className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg inline-flex items-center"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Upload
        </Link>
      </div>
    );
  }

  // Prepare chart data
  const chartData: ChartData<'doughnut'> = {
    labels: ['Pneumonia', 'Normal'],
    datasets: [
      {
        data: result.prediction === 'PNEUMONIA' 
          ? [result.confidence * 100, (1 - result.confidence) * 100]
          : [(1 - result.confidence) * 100, result.confidence * 100],
        backgroundColor: [
          'rgba(220, 38, 38, 0.8)',
          'rgba(16, 185, 129, 0.8)'
        ],
        borderColor: [
          'rgba(220, 38, 38, 1)',
          'rgba(16, 185, 129, 1)'
        ],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions: ChartOptions<'doughnut'> = {
    cutout: '70%',
    plugins: {
      legend: {
        position: 'bottom',
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `${context.label}: ${context.raw}%`;
          }
        }
      }
    },
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-6 flex items-center">
        <Link 
          to="/history" 
          className="text-blue-600 hover:text-blue-800 inline-flex items-center mr-4"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to History
        </Link>
        <h1 className="text-2xl font-bold text-gray-800">Analysis Results</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 bg-gray-50 border-b">
            <h2 className="font-semibold text-gray-800">X-Ray Image</h2>
          </div>
          <div className="p-6 flex justify-center">
            {result.imageUrl ? (
              <img 
                src={result.imageUrl} 
                alt="X-ray" 
                className="max-h-80 rounded"
              />
            ) : (
              <div className="bg-gray-100 w-full h-64 flex items-center justify-center rounded">
                <p className="text-gray-500">Image not available</p>
              </div>
            )}
          </div>
          <div className="px-6 pb-4">
            <div className="text-sm text-gray-500">
              <div className="flex justify-between mb-1">
                <span>Filename:</span>
                <span className="font-medium text-gray-700">{result.filename}</span>
              </div>
              <div className="flex justify-between">
                <span>Uploaded:</span>
                <span className="font-medium text-gray-700">
                  {formatDistanceToNow(new Date(result.date), { addSuffix: true })}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 bg-gray-50 border-b">
            <h2 className="font-semibold text-gray-800">Detection Results</h2>
          </div>
          
          <div className="p-6">
            <div className="mb-6 text-center">
              <div className="w-48 h-48 mx-auto">
                <Doughnut data={chartData} options={chartOptions} />
              </div>
            </div>
            
            <div className={`rounded-lg p-4 mb-4 flex items-center ${
              result.prediction === 'PNEUMONIA' 
                ? 'bg-red-50 text-red-800' 
                : 'bg-green-50 text-green-800'
            }`}>
              {result.prediction === 'PNEUMONIA' ? (
                <AlertTriangle className="h-6 w-6 mr-3 flex-shrink-0" />
              ) : (
                <Check className="h-6 w-6 mr-3 flex-shrink-0" />
              )}
              <div>
                <p className="font-semibold">
                  {result.prediction === 'PNEUMONIA' 
                    ? 'Pneumonia Detected' 
                    : 'No Pneumonia Detected'}
                </p>
                <p className="text-sm opacity-90">
                  Confidence: {(result.confidence * 100).toFixed(1)}%
                </p>
              </div>
            </div>
            
            <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-800">
              <div className="flex">
                <Info className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium mb-1">Important Note</p>
                  <p>This is an AI-assisted analysis and should not replace professional medical diagnosis. Please consult with a healthcare provider for proper medical advice.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="px-6 pb-6">
            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded flex items-center justify-center">
              <Download className="h-4 w-4 mr-2" />
              Download Report
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-4 bg-gray-50 border-b">
          <h2 className="font-semibold text-gray-800">Detailed Analysis</h2>
        </div>
        <div className="p-6">
          <div className="mb-4">
            <h3 className="font-medium text-gray-800 mb-2">Key Findings</h3>
            <p className="text-gray-600 mb-3">
              {result.prediction === 'PNEUMONIA' 
                ? 'The analysis indicates patterns consistent with pneumonia. The AI model has detected areas of opacity that may represent consolidation in the lung fields.' 
                : 'The analysis indicates normal lung patterns. The AI model has not detected significant areas of opacity or consolidation in the lung fields.'}
            </p>
            <p className="text-gray-600">
              {result.prediction === 'PNEUMONIA'
                ? 'Pneumonia often presents as areas of increased opacity or consolidation in the lung fields. The detected pattern shows characteristics commonly associated with pneumonia infection.'
                : 'The lung fields appear clear with normal vascular markings. No significant areas of consolidation, effusion, or other abnormalities are detected.'}
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-2">Model Explanation</h3>
            <p className="text-gray-600 mb-3">
              This analysis was performed using a deep learning model trained on a large dataset of chest X-rays. The model analyzes patterns and features in the image to identify characteristics associated with pneumonia.
            </p>
            <p className="text-gray-600">
              The confidence score represents how certain the model is about its prediction, but should not be interpreted as diagnostic certainty. Higher confidence scores indicate stronger pattern recognition, but clinical correlation is always necessary.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Results;