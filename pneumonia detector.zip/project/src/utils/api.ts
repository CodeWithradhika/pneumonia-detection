import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export interface PredictionResult {
  prediction: 'PNEUMONIA' | 'NORMAL';
  confidence: number;
  id: string;
}

export const analyzeXray = async (file: File): Promise<PredictionResult> => {
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await axios.post(`${API_URL}/predict`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    return response.data;
  } catch (error) {
    console.error('Error analyzing X-ray:', error);
    throw new Error('Failed to analyze X-ray image. Please try again.');
  }
};

export const getHistoryItem = async (id: string) => {
  try {
    const response = await axios.get(`${API_URL}/results/${id}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching result:', error);
    throw new Error('Failed to fetch result data. Please try again.');
  }
};

export const getHistory = async () => {
  try {
    const response = await axios.get(`${API_URL}/history`);
    return response.data;
  } catch (error) {
    console.error('Error fetching history:', error);
    throw new Error('Failed to fetch history data. Please try again.');
  }
};